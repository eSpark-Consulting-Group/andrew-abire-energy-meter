#ifndef FUNC_PROTOTYPE_USER_H
#define FUNC_PROTOTYPE_USER_H

#include <Arduino.h>
#include <FS.h>
#include <SD.h>

void MenuFuncSetDatetime(void);
void MenuFuncCarbonCredit(void);
void MenuFuncHistoryFault(void);
void MenuFuncSystemInfo(void);

// 2.System Settings
void MenuFuncSetPumpHead(void);
void MenuFuncSetMinDcv(void);
void MenuFuncSetSlowdownDcv(void);
void MenuFuncSetDcAmp(void);
void MenuFuncResetStrokeCount(void);
void MenuFuncResetRuntime(void);
void MenuFuncSetDioMode(void);
void MenuFuncComFailAction(void);
void MenuFuncSetVolumeUnit(void);
void MenuFuncSetTempUnit(void);
void MenuFuncSetTempCtrl(void);
void MenuFuncSetOffTemp(void);
void MenuFuncSetOnTemp(void);

// 4. SCADA Settings
void MenuFuncSetProtocol(void);
void MenuFuncSetServerID(void);
void MenuFuncSetTimeout(void);
void MenuFuncSetCoilAddr(void);
void MenuFuncSetDiscInputAddr(void);
void MenuFuncSetInputRegAddr(void);
void MenuFuncSetHoldRegAddr(void);
void MenuFuncSetBaudrate(void);
void MenuFuncSetDataBit(void);
void MenuFuncSetStopBit(void);
void MenuFuncSetParity(void);
void MenuFuncSetPumpRate(void);
void MenuFuncSetStrokeRate(void);

// PH #n
void MenuFuncSetGearRatio(void);
void MenuFuncSetPistonDiameter(void);
void MenuFuncSetStrokeLength(void);
void MenuFuncSetPumpRate(void);
void MenuFuncCalibration(void);

void mbServerRegisterWorkers(void);
void LcdUpdate(void);
void LcdPrepareBuffer(void);
void lockKeys(byte lock);
void runSdDatalogger(fs::FS &fs);
				 
#endif
