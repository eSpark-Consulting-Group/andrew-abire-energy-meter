# FIXED

hal.obj: ../hal.c
hal.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/hal.h
hal.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/hal_obj.h
hal.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/adc.h
hal.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/cpu.h
hal.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/types.h
hal.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/stdbool.h
hal.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/_ti_config.h
hal.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/linkage.h
hal.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/string.h
hal.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/sys/cdefs.h
hal.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/xlocale/_string.h
hal.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/stdint.h
hal.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/_stdint40.h
hal.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/sys/stdint.h
hal.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/sys/_types.h
hal.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/machine/_types.h
hal.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/machine/_stdint.h
hal.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/sys/_stdint.h
hal.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/clk.h
hal.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/pwm.h
hal.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/drv8305.h
hal.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/gpio.h
hal.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/spi.h
hal.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/flash.h
hal.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/offset.h
hal.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/filter_fo.h
hal.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/IQmathLib.h
hal.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/limits.h
hal.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/osc.h
hal.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/pie.h
hal.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/pll.h
hal.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/pwmdac.h
hal.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/pwr.h
hal.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/sci.h
hal.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/timer.h
hal.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/usDelay.h
hal.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/user.h
hal.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/ctrl_obj.h
hal.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/angle_gen.h
hal.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/math.h
hal.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/clarke.h
hal.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/ctrl_states.h
hal.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/datalog.h
hal.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/est.h
hal.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/est_states.h
hal.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/ipark.h
hal.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/motor.h
hal.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/park.h
hal.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/pid.h
hal.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/svgen.h
hal.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/traj.h
hal.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/vs_freq.h
hal.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/est_Flux_states.h
hal.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/est_Ls_states.h
hal.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/est_Rs_states.h
hal.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/userParams.h
hal.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/wdog.h
hal.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/svgen_current.h

../hal.c:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/hal.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/hal_obj.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/adc.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/cpu.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/types.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/stdbool.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/_ti_config.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/linkage.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/string.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/sys/cdefs.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/xlocale/_string.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/stdint.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/_stdint40.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/sys/stdint.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/sys/_types.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/machine/_types.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/machine/_stdint.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/sys/_stdint.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/clk.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/pwm.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/drv8305.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/gpio.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/spi.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/flash.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/offset.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/filter_fo.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/IQmathLib.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/limits.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/osc.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/pie.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/pll.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/pwmdac.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/pwr.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/sci.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/timer.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/usDelay.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/user.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/ctrl_obj.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/angle_gen.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/math.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/clarke.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/ctrl_states.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/datalog.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/est.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/est_states.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/ipark.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/motor.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/park.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/pid.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/svgen.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/traj.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/vs_freq.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/est_Flux_states.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/est_Ls_states.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/est_Rs_states.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/userParams.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/wdog.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/svgen_current.h:

