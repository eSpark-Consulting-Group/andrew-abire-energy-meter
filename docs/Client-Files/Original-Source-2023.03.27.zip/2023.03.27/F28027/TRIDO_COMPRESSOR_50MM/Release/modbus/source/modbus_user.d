# FIXED

modbus/source/modbus_user.obj: ../modbus/source/modbus_user.c
modbus/source/modbus_user.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/main.h
modbus/source/modbus_user.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/flyingStart.h
modbus/source/modbus_user.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/ctrl.h
modbus/source/modbus_user.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/clarke.h
modbus/source/modbus_user.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/IQmathLib.h
modbus/source/modbus_user.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/limits.h
modbus/source/modbus_user.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/_ti_config.h
modbus/source/modbus_user.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/linkage.h
modbus/source/modbus_user.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/math.h
modbus/source/modbus_user.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/types.h
modbus/source/modbus_user.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/stdbool.h
modbus/source/modbus_user.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/string.h
modbus/source/modbus_user.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/sys/cdefs.h
modbus/source/modbus_user.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/xlocale/_string.h
modbus/source/modbus_user.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/stdint.h
modbus/source/modbus_user.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/_stdint40.h
modbus/source/modbus_user.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/sys/stdint.h
modbus/source/modbus_user.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/sys/_types.h
modbus/source/modbus_user.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/machine/_types.h
modbus/source/modbus_user.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/machine/_stdint.h
modbus/source/modbus_user.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/sys/_stdint.h
modbus/source/modbus_user.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/ctrl_obj.h
modbus/source/modbus_user.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/angle_gen.h
modbus/source/modbus_user.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/ctrl_states.h
modbus/source/modbus_user.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/datalog.h
modbus/source/modbus_user.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/est.h
modbus/source/modbus_user.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/est_states.h
modbus/source/modbus_user.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/ipark.h
modbus/source/modbus_user.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/motor.h
modbus/source/modbus_user.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/offset.h
modbus/source/modbus_user.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/filter_fo.h
modbus/source/modbus_user.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/park.h
modbus/source/modbus_user.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/pid.h
modbus/source/modbus_user.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/svgen.h
modbus/source/modbus_user.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/traj.h
modbus/source/modbus_user.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/vs_freq.h
modbus/source/modbus_user.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/hal_obj.h
modbus/source/modbus_user.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/adc.h
modbus/source/modbus_user.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/cpu.h
modbus/source/modbus_user.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/clk.h
modbus/source/modbus_user.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/pwm.h
modbus/source/modbus_user.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/drv8305.h
modbus/source/modbus_user.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/gpio.h
modbus/source/modbus_user.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/spi.h
modbus/source/modbus_user.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/flash.h
modbus/source/modbus_user.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/osc.h
modbus/source/modbus_user.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/pie.h
modbus/source/modbus_user.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/pll.h
modbus/source/modbus_user.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/pwmdac.h
modbus/source/modbus_user.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/pwr.h
modbus/source/modbus_user.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/sci.h
modbus/source/modbus_user.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/timer.h
modbus/source/modbus_user.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/usDelay.h
modbus/source/modbus_user.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/user.h
modbus/source/modbus_user.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/est_Flux_states.h
modbus/source/modbus_user.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/est_Ls_states.h
modbus/source/modbus_user.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/est_Rs_states.h
modbus/source/modbus_user.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/userParams.h
modbus/source/modbus_user.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/wdog.h
modbus/source/modbus_user.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/cpu_time.h
modbus/source/modbus_user.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/math.h
modbus/source/modbus_user.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/_defs.h
modbus/source/modbus_user.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/machine/_limits.h
modbus/source/modbus_user.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/cpu_usage.h
modbus/source/modbus_user.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/fem.h
modbus/source/modbus_user.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/fw.h
modbus/source/modbus_user.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/hal.h
modbus/source/modbus_user.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/svgen_current.h
modbus/source/modbus_user.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/hallbldc.h
modbus/source/modbus_user.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/memCopy.h
modbus/source/modbus_user.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/modbus/include/modbus_user.h
modbus/source/modbus_user.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/modbus/include/userio.h
modbus/source/modbus_user.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/modbus/include/emavg.h
modbus/source/modbus_user.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/modbus/include/scidrv.h
modbus/source/modbus_user.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/modbus/include/modbus_slave.h
modbus/source/modbus_user.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/stdlib.h
modbus/source/modbus_user.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/stdlibf.h

../modbus/source/modbus_user.c:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/main.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/flyingStart.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/ctrl.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/clarke.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/IQmathLib.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/limits.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/_ti_config.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/linkage.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/math.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/types.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/stdbool.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/string.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/sys/cdefs.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/xlocale/_string.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/stdint.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/_stdint40.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/sys/stdint.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/sys/_types.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/machine/_types.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/machine/_stdint.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/sys/_stdint.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/ctrl_obj.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/angle_gen.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/ctrl_states.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/datalog.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/est.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/est_states.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/ipark.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/motor.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/offset.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/filter_fo.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/park.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/pid.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/svgen.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/traj.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/vs_freq.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/hal_obj.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/adc.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/cpu.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/clk.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/pwm.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/drv8305.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/gpio.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/spi.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/flash.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/osc.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/pie.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/pll.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/pwmdac.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/pwr.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/sci.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/timer.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/usDelay.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/user.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/est_Flux_states.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/est_Ls_states.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/est_Rs_states.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/userParams.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/wdog.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/cpu_time.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/math.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/_defs.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/machine/_limits.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/cpu_usage.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/fem.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/fw.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/hal.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/svgen_current.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/hallbldc.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/memCopy.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/modbus/include/modbus_user.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/modbus/include/userio.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/modbus/include/emavg.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/modbus/include/scidrv.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/modbus/include/modbus_slave.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/stdlib.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/stdlibf.h:

