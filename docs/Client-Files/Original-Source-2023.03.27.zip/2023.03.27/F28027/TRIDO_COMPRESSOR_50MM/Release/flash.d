# FIXED

flash.obj: ../flash.c
flash.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/flash.h
flash.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/cpu.h
flash.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/types.h
flash.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/stdbool.h
flash.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/_ti_config.h
flash.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/linkage.h
flash.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/string.h
flash.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/sys/cdefs.h
flash.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/xlocale/_string.h
flash.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/stdint.h
flash.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/_stdint40.h
flash.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/sys/stdint.h
flash.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/sys/_types.h
flash.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/machine/_types.h
flash.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/machine/_stdint.h
flash.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/sys/_stdint.h

../flash.c:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/flash.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/cpu.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/types.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/stdbool.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/_ti_config.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/linkage.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/string.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/sys/cdefs.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/xlocale/_string.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/stdint.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/_stdint40.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/sys/stdint.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/sys/_types.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/machine/_types.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/machine/_stdint.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/sys/_stdint.h:

