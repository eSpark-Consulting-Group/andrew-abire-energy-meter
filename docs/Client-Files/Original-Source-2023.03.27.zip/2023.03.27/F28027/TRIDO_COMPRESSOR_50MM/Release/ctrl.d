# FIXED

ctrl.obj: ../ctrl.c
ctrl.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/ctrl.h
ctrl.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/clarke.h
ctrl.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/IQmathLib.h
ctrl.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/limits.h
ctrl.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/_ti_config.h
ctrl.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/linkage.h
ctrl.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/math.h
ctrl.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/types.h
ctrl.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/stdbool.h
ctrl.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/string.h
ctrl.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/sys/cdefs.h
ctrl.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/xlocale/_string.h
ctrl.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/stdint.h
ctrl.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/_stdint40.h
ctrl.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/sys/stdint.h
ctrl.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/sys/_types.h
ctrl.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/machine/_types.h
ctrl.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/machine/_stdint.h
ctrl.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/sys/_stdint.h
ctrl.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/ctrl_obj.h
ctrl.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/angle_gen.h
ctrl.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/ctrl_states.h
ctrl.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/datalog.h
ctrl.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/est.h
ctrl.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/est_states.h
ctrl.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/ipark.h
ctrl.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/motor.h
ctrl.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/offset.h
ctrl.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/filter_fo.h
ctrl.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/park.h
ctrl.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/pid.h
ctrl.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/svgen.h
ctrl.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/traj.h
ctrl.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/vs_freq.h
ctrl.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/hal_obj.h
ctrl.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/adc.h
ctrl.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/cpu.h
ctrl.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/clk.h
ctrl.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/pwm.h
ctrl.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/drv8305.h
ctrl.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/gpio.h
ctrl.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/spi.h
ctrl.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/flash.h
ctrl.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/osc.h
ctrl.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/pie.h
ctrl.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/pll.h
ctrl.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/pwmdac.h
ctrl.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/pwr.h
ctrl.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/sci.h
ctrl.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/timer.h
ctrl.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/usDelay.h
ctrl.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/user.h
ctrl.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/est_Flux_states.h
ctrl.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/est_Ls_states.h
ctrl.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/est_Rs_states.h
ctrl.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/userParams.h
ctrl.obj: F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/wdog.h
ctrl.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/math.h
ctrl.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/_defs.h
ctrl.obj: C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/machine/_limits.h
ctrl.obj: ../include/dlog4ch.h
ctrl.obj: ../include/hal.h
ctrl.obj: ../include/svgen_current.h

../ctrl.c:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/ctrl.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/clarke.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/IQmathLib.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/limits.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/_ti_config.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/linkage.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/math.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/types.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/stdbool.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/string.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/sys/cdefs.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/xlocale/_string.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/stdint.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/_stdint40.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/sys/stdint.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/sys/_types.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/machine/_types.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/machine/_stdint.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/sys/_stdint.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/ctrl_obj.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/angle_gen.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/ctrl_states.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/datalog.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/est.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/est_states.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/ipark.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/motor.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/offset.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/filter_fo.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/park.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/pid.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/svgen.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/traj.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/vs_freq.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/hal_obj.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/adc.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/cpu.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/clk.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/pwm.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/drv8305.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/gpio.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/spi.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/flash.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/osc.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/pie.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/pll.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/pwmdac.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/pwr.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/sci.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/timer.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/usDelay.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/user.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/est_Flux_states.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/est_Ls_states.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/est_Rs_states.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/userParams.h:

F:/ESP32\ Project/workspace_trido_v12/TRIDO_COMPRESSOR_50MM/include/wdog.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/math.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/_defs.h:

C:/ti/ccs1200/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/machine/_limits.h:

../include/dlog4ch.h:

../include/hal.h:

../include/svgen_current.h:

